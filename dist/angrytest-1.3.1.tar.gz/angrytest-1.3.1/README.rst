This is the readme
Now included init py script.