DEFAULT = 10
DEFAULT_NAME = 'Angryziber'

def callPrint(val = DEFAULT) :
	print "Works with val ", val

def sayHi(name = DEFAULT_NAME) :
	print "Hi ",name

def talklToMe(name = DEFAULT_NAME) :
	print "What can i say?" ,name 

# callPrint()
# sayHi()
# talklToMe()